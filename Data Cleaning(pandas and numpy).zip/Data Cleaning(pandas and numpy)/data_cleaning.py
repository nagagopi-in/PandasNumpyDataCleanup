import pandas as pd
import numpy as np

# Load the dataset
file_path = r"C:\Users\NAGA GOPI\Downloads\Data-cleaning-for-beginners-using-pandas.csv"
df = pd.read_csv(file_path)

# 1. Missing Values
# Handle missing values by imputing them with their respective means.
df['Age'].fillna(df['Age'].mean(), inplace=True)

# Clean and extract numeric values from the 'Salary' column
df['Salary'] = df['Salary'].replace('[\$,]', '', regex=True)  # Remove dollar signs
df['Salary'] = df['Salary'].str.extract('(\d+)-(\d+)').astype(float).mean()  # Extract numeric range and calculate mean

# 2. Data Types
# Convert 'Established' to datetime and 'Rating' to float.
df['Established'] = pd.to_datetime(df['Established'], errors='coerce')
df['Rating'] = pd.to_numeric(df['Rating'], errors='coerce')

# 3. Outliers
# Identify and handle outliers in the 'Rating' column using Z-score.
z_scores = np.abs((df['Rating'] - df['Rating'].mean()) / df['Rating'].std())
df = df[(z_scores < 3)]  # Clip 'Rating' values to a specific range

# 4. Salary Formatting
# This step is already handled in the missing values section.

# 5. Location Standardization
# Convert 'Location' to lowercase for consistency.
df['Location'] = df['Location'].str.lower()

# 6. Established Column
# This step is already handled in the data types section.

# 7. Easy Apply Indicator
# Map 'Yes' to True and 'No' to False in the 'Easy Apply' column.
df['Easy Apply'] = df['Easy Apply'].map({'Yes': True, 'No': False})

# 8. Rating Range
# This step is already handled in the outliers section.

# 9. Age Distribution
# This step is already handled in the missing values section.

# 10. Handling Special Characters
# Remove non-alphanumeric characters from 'Location'.
df['Location'] = df['Location'].replace('[^a-zA-Z0-9 ]', '', regex=True)

# 11. Data Integrity
# Cross-reference entries to ensure data integrity.
# Check for inconsistencies or anomalies.

# 12. Easy Apply Transformation
# Transform 'Easy Apply' to boolean values for consistency.
df['Easy Apply'] = df['Easy Apply'].map({'Yes': True, 'No': False})

# 13. Location Accuracy
# Manually review unique location values and correct any inaccuracies.

# 14. Handling Categorical Data
# Use one-hot encoding for nominal variables or label encoding for ordinal variables.
# Ensure consistency in encoding across the dataset.

# Example:
# df = pd.get_dummies(df, columns=['CategoricalColumn'], drop_first=True)

# 15. Consistent Rating Scale
# Normalize or adjust the ratings to a common scale if necessary.

# Example:
# df['Rating'] = (df['Rating'] - df['Rating'].min()) / (df['Rating'].max() - df['Rating'].min()) * 10

# 16. Data Validation
# Perform sanity checks on key variables and relationships within the data.
# Check for unexpected values, patterns, or relationships that might indicate errors.

# Example:
# Validate that the mean age and salary are within reasonable bounds based on domain knowledge.

# 17. Documentation
# Document the steps taken to clean and manipulate the dataset.
# Include explanations for any transformations or imputations made during the process.
# Save the cleaned dataset
df.to_csv('cleaned_dataset.csv', index=False)

# Display the entire cleaned dataset
print(df)
