import pandas as pd

# 1. Reading TSV File
# Use the pd.read_csv function with sep='\t' to read the Chipotle TSV file into a pandas DataFrame.
file_path = r"C:\Users\NAGA GOPI\Downloads\chipotle.tsv"
chipotle_df = pd.read_csv(file_path, sep='\t')

# Check the actual column names in your dataset
print(chipotle_df.columns)

# 2. Missing Values
# Check for missing values in each column. Handle missing values based on the analysis requirements.
missing_values = chipotle_df.isnull().sum()

# ...

# 5. Quantity and Item Price
# Examine the Quantity and Item Price columns for inconsistencies.
# Assuming Item Price is a string with '$' signs, remove them and convert to float.
# Ensure that the column name matches the actual column name in your dataset.
if 'Item Price' in chipotle_df.columns:
    chipotle_df['Item Price'] = chipotle_df['Item Price'].replace('[\$,]', '', regex=True).astype(float)
else:
    print("Column 'Item Price' not found in the dataset.")

# ...

# Display the cleaned dataset
print(chipotle_df.head())
